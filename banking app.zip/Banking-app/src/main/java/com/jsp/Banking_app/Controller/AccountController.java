package com.jsp.Banking_app.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.Banking_app.Account.Account;
import com.jsp.Banking_app.Service.AccountService;

@RestController
public class AccountController {
	@Autowired
	AccountService service;
	
	//insert details
	
	@PostMapping("/accounts")
	
	public Account insertDetails(@RequestBody Account account)
	{
		return service.insertDetails(account);
	}
	
	//getting account by id
	
	@GetMapping("/accounts")
	
	public Account getByID(@RequestParam long id)
	{
		return service.getAccountById(id);
	}
	
	//deposit
	
	@PutMapping("/accounts")
	
	public String depositMoney(@RequestParam long id, @RequestParam double amount)
	{
		return service.deposit(id, amount);
	}
	
	//withdraw
	
	@PutMapping("/withdraw")
	
	public String withdraw(@RequestParam long id, @RequestParam double amount)
	{
		return service.withdraw(id, amount);
	}
	
	//to get all acoounts
	@GetMapping("/all")
	
	public List<Account> getAll()
	{
		return service.getAllAccounts();
	}
	
	//to delete
	
	@DeleteMapping("/accounts")
	
	public String deleteAccount(@RequestParam long id)
	{
		return service.deleteAccount(id);
	}
}
