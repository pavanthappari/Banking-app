package com.jsp.Banking_app.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jsp.Banking_app.Account.Account;

public interface AccountRepository extends JpaRepository<Account, Long>{

}
