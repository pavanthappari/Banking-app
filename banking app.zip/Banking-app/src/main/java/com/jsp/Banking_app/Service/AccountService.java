package com.jsp.Banking_app.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jsp.Banking_app.Account.Account;
import com.jsp.Banking_app.Repository.AccountRepository;

@Service
public class AccountService {
	@Autowired
	AccountRepository repository;
	
	//insert account details
	
	public Account insertDetails(Account account)
	{
		return repository.save(account);
	}
	
	// get account by id
	
	public Account getAccountById(long id)
	{
		Optional<Account> opt= repository.findById(id);
		
		if(opt.isPresent())
		{
			return opt.get();
		}
		else
		{
			return null;
		}
	}
	
	//deposit money
	
		public String deposit(long id, double amount)
		{
			Account a= getAccountById(id);
			
			if(a!=null)
			{
				double total= a.getBalance()+amount;
				a.setBalance(total);
				repository.save(a);
				return "Deposited successfully";
			}
			else
			{
				return "Id not found";
			}
		}
		
		//withdraw
		
		public String withdraw(long id, double amount)
		{
			Account a = getAccountById(id);
			if(a!=null)
			{
				double total= a.getBalance()-amount;
				a.setBalance(total);
				repository.save(a);
				return "Amount withdrawn";
			}
			else
			{
				return "Account not found";
			}
		}
		
		//to get all accounts
		
		public List<Account> getAllAccounts()
		{
			return repository.findAll();
		}
		
		//to delete account
		public String deleteAccount(long id)
		{
			Account a = getAccountById(id);
			
			if(a!=null)
			{
				repository.delete(a);
				return "Account deleted successfully";
			}
			else
			{
				return "account not found";
			}
		}
}
